from flask import Flask, render_template, request
import csv

app = Flask(__name__)

# Sample data for demonstration
accounts = [
    {"Account ID": 1, "Name": "John Doe", "journalid": "654321435"},
    {"Account ID": 2, "Name": "Jane Smith", "journalid": "63245435"},
    {"Account ID": 3, "Name": "Sam Wilson", "journalid": "634641435"},
    {"Account ID": 4, "Name": "Lisa Ray", "journalid": "654256735"},
]

@app.route("/", methods=["GET", "POST"])
def index():
    search_query = request.form.get("search", "").strip()
    print("**********",search_query)
    filtered_accounts = [
        acc
        for acc in accounts
        if search_query in acc["journalid"]
    ] if search_query else accounts
    
    show_table = bool(filtered_accounts)  # Only show table if there are results
    return render_template("base.html", accounts=filtered_accounts, show_table=show_table)
    
@app.route("/export_csv", methods=["GET"])
def export_csv():
    """Export accounts as a CSV file."""
    header = ["Account ID", "Name", "Balance"]
    filename = "accounts_export.csv"
    with open(filename, mode="w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(header)
        for account in accounts:
            writer.writerow(account.values())
    return jsonify({"message": "CSV exported successfully", "filename": filename})

if __name__ == "__main__":
    app.run(debug=True)
